-- phpMyAdmin SQL Dump
-- version 3.4.5deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 18, 2011 at 11:15 PM
-- Server version: 5.1.58
-- PHP Version: 5.3.6-13ubuntu3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `girafplace`
--

-- --------------------------------------------------------

--
-- Table structure for table `abilities`
--

DROP TABLE IF EXISTS `abilities`;
CREATE TABLE IF NOT EXISTS `abilities` (
  `abilityId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `applicationId` int(10) unsigned NOT NULL,
  `canRead` tinyint(1) NOT NULL DEFAULT '0',
  `canDragAndDrop` tinyint(1) NOT NULL DEFAULT '0',
  `canHear` tinyint(1) NOT NULL DEFAULT '0',
  `requiresSimpleVisualEffects` tinyint(1) NOT NULL DEFAULT '0',
  `canAnalogTime` tinyint(1) NOT NULL DEFAULT '0',
  `canDigitalTime` tinyint(1) NOT NULL DEFAULT '0',
  `requiresBigButtons` tinyint(1) NOT NULL DEFAULT '0',
  `canSpeak` tinyint(1) NOT NULL DEFAULT '0',
  `canNumbers` tinyint(1) NOT NULL DEFAULT '0',
  `canUseKeyboard` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`abilityId`),
  UNIQUE KEY `applicationId` (`applicationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `abilityDefinitions`
--

DROP TABLE IF EXISTS `abilityDefinitions`;
CREATE TABLE IF NOT EXISTS `abilityDefinitions` (
  `definitionId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier for the definition.',
  `definitionName` tinytext NOT NULL COMMENT 'Name of the definition (i.e. canHear, canSee, etc).',
  PRIMARY KEY (`definitionId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `adminId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adminName` text NOT NULL,
  `password` text NOT NULL,
  `accepted` tinyint(1) NOT NULL,
  `email` text NOT NULL,
  PRIMARY KEY (`adminId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `appInstallations`
--
DROP VIEW IF EXISTS `appInstallations`;
CREATE TABLE IF NOT EXISTS `appInstallations` (
`applicationId` int(10) unsigned
,`applicationName` text
,`deviceId` int(10) unsigned
,`profileName` varchar(100)
,`profileId` int(10) unsigned
);
-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
CREATE TABLE IF NOT EXISTS `applications` (
  `applicationId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier',
  `applicationName` text NOT NULL COMMENT 'Name of the app',
  `applicationSystemName` text NOT NULL,
  `applicationDescription` mediumtext NOT NULL COMMENT 'Description of the app',
  `package` text COMMENT 'Name of the package.',
  `version` int(11) DEFAULT NULL COMMENT 'Version of the package, described as a numeric.',
  `versionString` int(11) DEFAULT NULL COMMENT 'Version, described as a string?',
  `state` text COMMENT 'State of the package. Used by the php cron job.',
  `adminId` int(11) DEFAULT NULL COMMENT 'Administrator of the package.',
  `canDragAndDrop` tinyint(1) NOT NULL,
  `canHear` tinyint(1) NOT NULL,
  `requiresSimpleVisualEffects` tinyint(1) NOT NULL,
  `canAnalogTime` tinyint(1) NOT NULL,
  `canDigitalTime` tinyint(1) NOT NULL,
  `canRead` tinyint(1) NOT NULL,
  `hasBadVision` tinyint(1) NOT NULL,
  `requiresLargeButtons` tinyint(1) NOT NULL,
  `canSpeak` tinyint(1) NOT NULL,
  `canNumbers` tinyint(1) NOT NULL,
  `canUseKeyboard` tinyint(1) NOT NULL,
  PRIMARY KEY (`applicationId`),
  KEY `canNumbers` (`canNumbers`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

-- --------------------------------------------------------

--
-- Table structure for table `cbMessages`
--

DROP TABLE IF EXISTS `cbMessages`;
CREATE TABLE IF NOT EXISTS `cbMessages` (
  `messageId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msgParentKey` int(10) unsigned DEFAULT NULL COMMENT 'Key to the message that this is a reply to. Null if it is a prime message.',
  `msgChildKey` int(10) unsigned NOT NULL,
  `msgUserKey` int(10) unsigned NOT NULL COMMENT 'Key to the user that posted this message.',
  `msgTimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `msgSubject` text NOT NULL,
  `msgBody` text NOT NULL,
  PRIMARY KEY (`messageId`),
  KEY `msgChildKey` (`msgChildKey`),
  KEY `msgUserKey` (`msgUserKey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=88 ;

-- --------------------------------------------------------

--
-- Table structure for table `cbMessagesRead`
--

DROP TABLE IF EXISTS `cbMessagesRead`;
CREATE TABLE IF NOT EXISTS `cbMessagesRead` (
  `readId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msgKey` int(10) unsigned NOT NULL,
  `userKey` int(10) unsigned NOT NULL,
  PRIMARY KEY (`readId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Contains pairs of keys denoting unread messages.' AUTO_INCREMENT=121 ;

-- --------------------------------------------------------

--
-- Table structure for table `cbMsgImages`
--

DROP TABLE IF EXISTS `cbMsgImages`;
CREATE TABLE IF NOT EXISTS `cbMsgImages` (
  `imgId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msgKey` int(10) unsigned NOT NULL,
  `imgKey` int(10) unsigned NOT NULL COMMENT 'Key to the image resource in imageResources.',
  `imgText` text,
  PRIMARY KEY (`imgId`),
  KEY `msgKey` (`msgKey`),
  KEY `imgKey` (`imgKey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

-- --------------------------------------------------------

--
-- Table structure for table `childGroupKeys`
--

DROP TABLE IF EXISTS `childGroupKeys`;
CREATE TABLE IF NOT EXISTS `childGroupKeys` (
  `keyId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID of the association',
  `childKey` int(10) unsigned NOT NULL COMMENT 'Key of the child.',
  `groupKey` int(10) unsigned NOT NULL COMMENT 'Key of the group that the child belongs to.',
  PRIMARY KEY (`keyId`),
  KEY `childKey` (`childKey`,`groupKey`),
  KEY `groupKey` (`groupKey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `childUserKeys`
--

DROP TABLE IF EXISTS `childUserKeys`;
CREATE TABLE IF NOT EXISTS `childUserKeys` (
  `keyId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID of the association',
  `childKey` int(10) unsigned NOT NULL COMMENT 'Key of the child.',
  `userKey` int(10) unsigned NOT NULL COMMENT 'Key of the parent (user).',
  PRIMARY KEY (`keyId`),
  KEY `childKey` (`childKey`,`userKey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Contains links between users (parents) and children.' AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `devAppKeys`
--

DROP TABLE IF EXISTS `devAppKeys`;
CREATE TABLE IF NOT EXISTS `devAppKeys` (
  `keyId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `applicationKey` int(10) unsigned NOT NULL,
  `deviceKey` int(10) unsigned NOT NULL,
  PRIMARY KEY (`keyId`),
  KEY `applicationsKey` (`applicationKey`),
  KEY `deviceKey` (`deviceKey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
CREATE TABLE IF NOT EXISTS `devices` (
  `deviceId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier of the device.',
  `ownerId` int(10) unsigned DEFAULT NULL COMMENT 'Foreign key to profiles to denote the profile that owns/uses this device.',
  `deviceIdent` varchar(32) DEFAULT NULL COMMENT 'The device ident. This is currently defined as an MD5 of the device''s WiFi MAC address.',
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Timestamp for last change.',
  PRIMARY KEY (`deviceId`),
  UNIQUE KEY `deviceIdent` (`deviceIdent`),
  KEY `ownerId` (`ownerId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `errors`
--

DROP TABLE IF EXISTS `errors`;
CREATE TABLE IF NOT EXISTS `errors` (
  `errorId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `applicationId` int(10) unsigned NOT NULL,
  `errorMessage` mediumtext NOT NULL,
  PRIMARY KEY (`errorId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

-- --------------------------------------------------------

--
-- Table structure for table `groupModerators`
--

DROP TABLE IF EXISTS `groupModerators`;
CREATE TABLE IF NOT EXISTS `groupModerators` (
  `modId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier of the moderator connection.',
  `groupKey` int(10) unsigned NOT NULL COMMENT 'Key of the group that is moderated.',
  `userKey` int(10) unsigned NOT NULL COMMENT 'Key of the user that is to become moderator.',
  PRIMARY KEY (`modId`),
  KEY `groupKey` (`groupKey`),
  KEY `userKey` (`userKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `groupId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier of the group.',
  `groupName` text NOT NULL COMMENT 'Name of the group.',
  `adminKey` int(10) unsigned NOT NULL COMMENT 'Key to the user that is superuser of the group.',
  PRIMARY KEY (`groupId`),
  KEY `adminKey` (`adminKey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `imageResources`
--

DROP TABLE IF EXISTS `imageResources`;
CREATE TABLE IF NOT EXISTS `imageResources` (
  `imgId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `imgUri` text NOT NULL COMMENT 'URI to the image data. The PHP model can parse this into actual file resources.',
  `imageMimeType` varchar(255) NOT NULL COMMENT 'MIME type to help the client browserl',
  `imageSize` int(11) NOT NULL COMMENT 'Size in kb of the image. Also for the browser.',
  `imageData` mediumblob NOT NULL COMMENT 'Binary image data.',
  PRIMARY KEY (`imgId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Contains references to all uploaded images on the site.' AUTO_INCREMENT=43 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `kidsProfile_abilities`
--
DROP VIEW IF EXISTS `kidsProfile_abilities`;
CREATE TABLE IF NOT EXISTS `kidsProfile_abilities` (
`profileAbilityId` int(11)
,`profileKey` int(10) unsigned
,`definitionKey` int(10) unsigned
,`PA_lastUpdated` timestamp
,`definitionId` int(10) unsigned
,`definitionName` tinytext
,`profileId` int(10) unsigned
,`profileName` varchar(100)
,`profileBirthday` date
,`lastUpdated` timestamp
);
-- --------------------------------------------------------

--
-- Table structure for table `newsPosts`
--

DROP TABLE IF EXISTS `newsPosts`;
CREATE TABLE IF NOT EXISTS `newsPosts` (
  `newsId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID of the news post',
  `createTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Creation time of the post.',
  `updateTime` timestamp NULL DEFAULT NULL COMMENT 'Last time this post was edited.',
  `newsSubject` text NOT NULL COMMENT 'Subject of the news post.',
  `newsBody` text NOT NULL COMMENT 'Contents of the news post.',
  `groupKey` int(10) unsigned NOT NULL COMMENT 'Key to the group that this post is for.',
  `posterKey` int(10) unsigned NOT NULL COMMENT 'Key to the user that made this post.',
  PRIMARY KEY (`newsId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Contains news posts, both global and group-specific' AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `oversigtForbindelser`
--
DROP VIEW IF EXISTS `oversigtForbindelser`;
CREATE TABLE IF NOT EXISTS `oversigtForbindelser` (
`keyId` int(10) unsigned
,`childKey` int(10) unsigned
,`groupKey` int(10) unsigned
,`profileId` int(10) unsigned
,`profileName` varchar(100)
,`profileBirthday` date
,`lastUpdated` timestamp
,`groupId` int(10) unsigned
,`groupName` text
,`adminKey` int(10) unsigned
);
-- --------------------------------------------------------

--
-- Table structure for table `profileAbilities`
--

DROP TABLE IF EXISTS `profileAbilities`;
CREATE TABLE IF NOT EXISTS `profileAbilities` (
  `profileAbilityId` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identifier of a single ability for a profile.',
  `profileKey` int(10) unsigned NOT NULL COMMENT 'Key to the profile that this ability information is related to.',
  `definitionKey` int(10) unsigned NOT NULL,
  `PA_lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Timestamp of the last time this row was updated.',
  PRIMARY KEY (`profileAbilityId`),
  KEY `profileId` (`profileKey`),
  KEY `definitionId` (`definitionKey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
CREATE TABLE IF NOT EXISTS `profiles` (
  `profileId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier of a profile.',
  `profileName` varchar(100) NOT NULL COMMENT 'Name on the profile. This would be the name of the child.',
  `profileBirthday` date NOT NULL COMMENT 'Age of the profile/child.',
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Timestamp for last time this profile (or something related to this profile) was updated.',
  PRIMARY KEY (`profileId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `siteSettings`
--

DROP TABLE IF EXISTS `siteSettings`;
CREATE TABLE IF NOT EXISTS `siteSettings` (
  `settingId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Key for the setting.',
  `settingName` text NOT NULL COMMENT 'Name of the setting.',
  `settingValue` text NOT NULL COMMENT 'Actual value for the setting.',
  `settingDefault` text NOT NULL COMMENT 'Default value for the setting.',
  `settingType` text NOT NULL COMMENT 'String denoting the SQL type of the value.',
  PRIMARY KEY (`settingId`),
  UNIQUE KEY `SETTINGNAME` (`settingName`(30))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Contains global application settings that should not be in c' AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `tableRelations`
--

DROP TABLE IF EXISTS `tableRelations`;
CREATE TABLE IF NOT EXISTS `tableRelations` (
  `relationId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parentTable` int(10) NOT NULL,
  `parentKey` int(10) NOT NULL,
  `childTable` int(10) NOT NULL,
  `childKey` int(10) NOT NULL,
  PRIMARY KEY (`relationId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Contains table relation definitions.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `userGroupKeys`
--

DROP TABLE IF EXISTS `userGroupKeys`;
CREATE TABLE IF NOT EXISTS `userGroupKeys` (
  `keyId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID of the association',
  `groupKey` int(10) unsigned NOT NULL COMMENT 'Key of the group.',
  `userKey` int(10) unsigned NOT NULL COMMENT 'Key of the parent (user).',
  PRIMARY KEY (`keyId`),
  KEY `groupKey` (`groupKey`),
  KEY `userKey` (`userKey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Contains links between users (parents) and children.' AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `userId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Base identifier for a user.',
  `username` varchar(20) NOT NULL COMMENT 'The user''s login name.',
  `password` varchar(102) NOT NULL COMMENT 'Hashed password.',
  `fullname` text COMMENT 'The user''s full name.',
  `userMail` text NOT NULL COMMENT 'The user''s mail address.',
  `userRole` int(10) unsigned DEFAULT NULL COMMENT 'The user''s role key.',
  `lastAction` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'Shows when the user last made an action. Used to evaluate online status.',
  `statusKey` int(10) unsigned DEFAULT NULL COMMENT 'Key to the user''s current status.',
  PRIMARY KEY (`userId`),
  UNIQUE KEY `username` (`username`),
  KEY `statusKey` (`statusKey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Contains all loginnable users.' AUTO_INCREMENT=26 ;

-- --------------------------------------------------------

--
-- Table structure for table `userStatuses`
--

DROP TABLE IF EXISTS `userStatuses`;
CREATE TABLE IF NOT EXISTS `userStatuses` (
  `statusId` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Id of the status.',
  `statusName` text NOT NULL COMMENT 'Name for the status. Human-readable.',
  PRIMARY KEY (`statusId`),
  UNIQUE KEY `NAMEINDEX` (`statusName`(20))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Structure for view `appInstallations`
--
DROP TABLE IF EXISTS `appInstallations`;

CREATE ALGORITHM=UNDEFINED DEFINER=`giraf_web`@`%` SQL SECURITY DEFINER VIEW `appInstallations` AS select `applications`.`applicationId` AS `applicationId`,`applications`.`applicationName` AS `applicationName`,`devices`.`deviceId` AS `deviceId`,`profiles`.`profileName` AS `profileName`,`profiles`.`profileId` AS `profileId` from (`devAppKeys` join ((`applications` join `devices`) join `profiles`) on(((`applications`.`applicationId` = `devAppKeys`.`applicationKey`) and (`devices`.`deviceId` = `devAppKeys`.`deviceKey`) and (`devices`.`ownerId` = `devAppKeys`.`deviceKey`))));

-- --------------------------------------------------------

--
-- Structure for view `kidsProfile_abilities`
--
DROP TABLE IF EXISTS `kidsProfile_abilities`;

CREATE ALGORITHM=UNDEFINED DEFINER=`giraf_web`@`%` SQL SECURITY DEFINER VIEW `kidsProfile_abilities` AS select `profileAbilities`.`profileAbilityId` AS `profileAbilityId`,`profileAbilities`.`profileKey` AS `profileKey`,`profileAbilities`.`definitionKey` AS `definitionKey`,`profileAbilities`.`PA_lastUpdated` AS `PA_lastUpdated`,`abilityDefinitions`.`definitionId` AS `definitionId`,`abilityDefinitions`.`definitionName` AS `definitionName`,`profiles`.`profileId` AS `profileId`,`profiles`.`profileName` AS `profileName`,`profiles`.`profileBirthday` AS `profileBirthday`,`profiles`.`lastUpdated` AS `lastUpdated` from (`profileAbilities` left join (`abilityDefinitions` join `profiles`) on(((`profiles`.`profileId` = `profileAbilities`.`profileKey`) and (`abilityDefinitions`.`definitionId` = `profileAbilities`.`definitionKey`))));

-- --------------------------------------------------------

--
-- Structure for view `oversigtForbindelser`
--
DROP TABLE IF EXISTS `oversigtForbindelser`;

CREATE ALGORITHM=UNDEFINED DEFINER=`giraf_web`@`%` SQL SECURITY DEFINER VIEW `oversigtForbindelser` AS select `childGroupKeys`.`keyId` AS `keyId`,`childGroupKeys`.`childKey` AS `childKey`,`childGroupKeys`.`groupKey` AS `groupKey`,`profiles`.`profileId` AS `profileId`,`profiles`.`profileName` AS `profileName`,`profiles`.`profileBirthday` AS `profileBirthday`,`profiles`.`lastUpdated` AS `lastUpdated`,`groups`.`groupId` AS `groupId`,`groups`.`groupName` AS `groupName`,`groups`.`adminKey` AS `adminKey` from (`childGroupKeys` left join (`profiles` join `groups`) on(((`profiles`.`profileId` = `childGroupKeys`.`childKey`) and (`groups`.`groupId` = `childGroupKeys`.`groupKey`))));

--
-- Constraints for dumped tables
--

--
-- Constraints for table `childGroupKeys`
--
ALTER TABLE `childGroupKeys`
  ADD CONSTRAINT `childGroupKeys_ibfk_1` FOREIGN KEY (`childKey`) REFERENCES `profiles` (`profileId`) ON DELETE CASCADE,
  ADD CONSTRAINT `childGroupKeys_ibfk_2` FOREIGN KEY (`groupKey`) REFERENCES `groups` (`groupId`) ON DELETE CASCADE;

--
-- Constraints for table `devAppKeys`
--
ALTER TABLE `devAppKeys`
  ADD CONSTRAINT `devAppKeys_ibfk_1` FOREIGN KEY (`applicationKey`) REFERENCES `applications` (`applicationId`),
  ADD CONSTRAINT `devAppKeys_ibfk_2` FOREIGN KEY (`deviceKey`) REFERENCES `devices` (`deviceId`);

--
-- Constraints for table `groupModerators`
--
ALTER TABLE `groupModerators`
  ADD CONSTRAINT `groupModerators_ibfk_1` FOREIGN KEY (`groupKey`) REFERENCES `groups` (`groupId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `groupModerators_ibfk_2` FOREIGN KEY (`userKey`) REFERENCES `users` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `groups`
--
ALTER TABLE `groups`
  ADD CONSTRAINT `groups_ibfk_1` FOREIGN KEY (`adminKey`) REFERENCES `users` (`userId`);

--
-- Constraints for table `userGroupKeys`
--
ALTER TABLE `userGroupKeys`
  ADD CONSTRAINT `userGroupKeys_ibfk_1` FOREIGN KEY (`groupKey`) REFERENCES `groups` (`groupId`),
  ADD CONSTRAINT `userGroupKeys_ibfk_2` FOREIGN KEY (`userKey`) REFERENCES `users` (`userId`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`statusKey`) REFERENCES `userStatuses` (`statusId`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
